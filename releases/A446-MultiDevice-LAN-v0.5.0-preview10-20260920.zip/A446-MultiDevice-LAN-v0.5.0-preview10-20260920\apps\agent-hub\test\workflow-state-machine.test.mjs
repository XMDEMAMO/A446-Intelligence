import test from "node:test";
import assert from "node:assert/strict";
import { AgentHub } from "../src/hub.mjs";
import { delay } from "../src/common.mjs";

test("Hub authoritative validation triggers automatic format retry once, then escalates to human intervention", async () => {
  const hub = new AgentHub({ logs: { includePayloads: true } });
  const executor = agent("executor-1", "executor");
  hub.agents.set("executor-1", executor);

  const root = hub.createTask({
    input: "Do work",
    targetAgentId: "executor-1",
    role: "executor",
    stage: "execution",
    workflow: { enabled: true },
  });
  await hub.queueOrDispatch(root);
  assert.equal(root.status, "dispatched");

  // Attempt 1: Worker sends broken JSON with unescaped internal quotes
  const attemptId1 = root.currentAttemptId;
  const brokenJson = '{"brief": "网站测试：所有agent输出"火区"两个字", "fullResult": "done"}';
  await hub.handleWorkerMessage("executor-1", {
    id: "msg-1",
    type: "task.result",
    taskId: root.taskId,
    payload: {
      attemptId: attemptId1,
      output: brokenJson,
    },
  });

  // Hub rejects and triggers 1-time format retry
  assert.equal(root.formatRetryCount, 1);
  assert.equal(root.status, "dispatched"); // Re-dispatched for retry
  assert.match(root.input, /【格式错误需修正】/);
  assert.ok(root.diagnosis?.formatError);
  // Chat messages should NOT contain the broken JSON as a normal task brief
  assert.equal(hub.messages.some((m) => m.kind === "task_brief"), false);

  // Attempt 2: Worker sends broken JSON again
  await hub.handleWorkerMessage("executor-1", {
    id: "msg-2",
    type: "task.result",
    taskId: root.taskId,
    payload: {
      output: 'still not json',
    },
  });

  // Hub now marks task as failed and requires human intervention
  assert.equal(root.status, "failed");
  assert.equal(root.error?.name, "FormatValidationError");
  const intervention = [...hub.interventions.values()].find((i) => i.taskId === root.taskId);
  assert.ok(intervention, "Human intervention created on second format failure");
  assert.equal(intervention.status, "pending");
  assert.match(intervention.question, /任务格式校验失败/);
  assert.equal(hub.conversations().find((c) => c.rootTaskId === root.rootTaskId)?.status, "needs_human");
});

test("Prohibition of self-review: executor cannot review itself and waits for human review if no independent reviewer exists", async () => {
  const hub = new AgentHub({ logs: { includePayloads: true } });
  // Only executor-1 is online
  const executor = agent("executor-1", "executor");
  hub.agents.set("executor-1", executor);

  const root = hub.createTask({
    input: "Solo task",
    role: "planner",
    workflow: { enabled: true, executorAgentId: "executor-1" },
  });
  const execTask = hub.createTask({
    input: "Execute solo",
    rootTaskId: root.taskId,
    parentTaskId: root.taskId,
    targetAgentId: "executor-1",
    role: "executor",
    stage: "execution",
    workflow: root.workflow,
  });
  execTask.submission = { brief: "Solo work done", fullResult: "Solo full result" };

  // Trigger advanceWorkflow on executor result
  await hub.advanceWorkflow(execTask);

  // Since executor-1 is the only agent and cannot self-review, it must wait for human review!
  assert.equal(execTask.reviewStatus, "waiting_for_human_review");
  const intervention = [...hub.interventions.values()].find((i) => i.taskId === execTask.taskId);
  assert.ok(intervention, "Human review intervention created");
  assert.equal(intervention.continuation?.type, "human_review");
  assert.match(intervention.question, /严禁由 Executor 自行审核/);

  // Admin approves human review
  const admin = { id: "admin-1", role: "admin" };
  await hub.resolveIntervention(intervention.interventionId, { action: "approve", response: "Looks good" }, admin);

  assert.equal(execTask.reviewStatus, "approved");
  // A planner result_intake task must have been spawned
  const intakeTask = [...hub.tasks.values()].find((t) => t.stage === "result_intake");
  assert.ok(intakeTask, "Planner result_intake spawned after human approval");
});

test("Four Pillars completion: workflow only completes when all four conditions are met", async () => {
  const hub = new AgentHub({ logs: { includePayloads: true } });
  hub.agents.set("planner-1", agent("planner-1", "planner"));
  hub.agents.set("executor-1", agent("executor-1", "executor"));
  hub.agents.set("reviewer-1", agent("reviewer-1", "reviewer"));

  const root = hub.createTask({
    input: "Full workflow",
    role: "planner",
    targetAgentId: "planner-1",
    workflow: { enabled: true, plannerAgentId: "planner-1", executorAgentId: "executor-1", reviewerAgentId: "reviewer-1" },
  });
  root.status = "completed";

  // Pillar check 1: No execution tasks -> Stalled, NOT completed!
  assert.equal(hub.isWorkflowComplete(root.taskId), false);
  assert.equal(hub.conversations()[0].status, "stalled");

  // Create completed execution task
  const execTask = hub.createTask({
    input: "Do work",
    rootTaskId: root.taskId,
    parentTaskId: root.taskId,
    targetAgentId: "executor-1",
    role: "executor",
    stage: "execution",
    workflow: root.workflow,
  });
  execTask.status = "completed";
  execTask.submission = { brief: "Done", fullResult: "Full result" };

  // Pillar check 2: Not reviewed yet -> Not complete!
  assert.equal(hub.isWorkflowComplete(root.taskId), false);

  // Review task approved by independent reviewer-1
  const reviewTask = hub.createTask({
    input: "Review work",
    rootTaskId: root.taskId,
    parentTaskId: execTask.taskId,
    targetAgentId: "reviewer-1",
    role: "reviewer",
    stage: "result_review",
    workflow: root.workflow,
  });
  reviewTask.status = "completed";
  execTask.reviewStatus = "approved";

  // Pillar check 3: Approved, but planner has not issued explicit decision: "complete" -> Not complete!
  assert.equal(hub.isWorkflowComplete(root.taskId), false);

  // Planner issues explicit complete decision in result_intake
  const intakeTask = hub.createTask({
    input: "Intake results",
    rootTaskId: root.taskId,
    parentTaskId: reviewTask.taskId,
    targetAgentId: "planner-1",
    role: "planner",
    stage: "result_intake",
    workflow: root.workflow,
  });
  intakeTask.status = "completed";
  intakeTask.submission = { decision: "complete", brief: "Verified all results", assignments: [] };

  // All Four Pillars are now satisfied!
  assert.equal(hub.isWorkflowComplete(root.taskId), true);
  hub.checkAndFinalizeWorkflow(root.taskId);
  assert.equal(root.status, "completed");
  assert.equal(hub.conversations()[0].status, "completed");
});

test("Scheduling failure provides structured feedback to planner, retries once, then requires human", async () => {
  const hub = new AgentHub({ logs: { includePayloads: true } });
  hub.agents.set("planner-1", agent("planner-1", "planner"));
  // executor-1 has no capabilities
  const executor = agent("executor-1", "executor");
  executor.capabilities = [];
  executor.models = [];
  hub.agents.set("executor-1", executor);

  const root = hub.createTask({
    input: "Scheduling test",
    role: "planner",
    targetAgentId: "planner-1",
    workflow: { enabled: true, plannerAgentId: "planner-1" },
  });

  const plannerTask = hub.createTask({
    input: "Plan tasks",
    rootTaskId: root.taskId,
    targetAgentId: "planner-1",
    role: "planner",
    stage: "planning",
    workflow: root.workflow,
  });
  plannerTask.submission = {
    brief: "Assign task requiring non-existent capability",
    assignments: [
      {
        title: "Heavy Task",
        instructions: "Run quantum math",
        requiredCapabilities: ["quantum_compute"],
        targetAgentId: "executor-1",
      },
    ],
  };

  // Dispatch assignments
  await hub.advanceWorkflow(plannerTask);

  // Child task failed scheduling -> Hub cancels child and gives structured feedback to planner in replan stage
  const replanTask = [...hub.tasks.values()].find((t) => t.stage === "replan");
  assert.ok(replanTask, "Planner received replan task after scheduling failure");
  assert.ok(replanTask.contextBundle?.schedulingFailure, "Structured failure feedback provided");
  assert.match(replanTask.contextBundle.schedulingFailure.assignmentTitle, /Heavy Task/);

  // If second plan also schedules impossible task -> Hub requires human intervention
  replanTask.submission = {
    brief: "Try again with impossible model",
    assignments: [
      {
        title: "Heavy Task 2",
        instructions: "Run again",
        requiredCapabilities: ["quantum_compute"],
        targetAgentId: "executor-1",
      },
    ],
  };
  await hub.advanceWorkflow(replanTask);

  const intervention = [...hub.interventions.values()].find((i) => i.question?.includes("调度失败"));
  assert.ok(intervention, "Human intervention created after second scheduling failure");
});

test("Workflow circuit breaker triggers human intervention at 50 task limit", async () => {
  const hub = new AgentHub({ logs: { includePayloads: true } });
  const root = hub.createTask({
    input: "Infinite loop task",
    role: "planner",
    workflow: { enabled: true },
  });

  // Pre-populate 49 child tasks in the workflow
  for (let i = 0; i < 49; i++) {
    hub.createTask({
      input: `Task ${i}`,
      rootTaskId: root.taskId,
      role: "executor",
      stage: "execution",
      status: "completed",
    });
  }

  // Next task advance triggers circuit breaker
  const plannerTask = hub.createTask({
    input: "50th task",
    rootTaskId: root.taskId,
    role: "planner",
    stage: "planning",
    workflow: root.workflow,
  });
  plannerTask.submission = {
    brief: "One more task",
    assignments: [{ title: "T", instructions: "I" }],
  };

  await hub.advanceWorkflow(plannerTask);

  const intervention = [...hub.interventions.values()].find((i) => i.question?.includes("上限（50次）"));
  assert.ok(intervention, "Circuit breaker created human intervention at 50 tasks");
});

function agent(agentId, role) {
  return {
    agentId,
    status: "online",
    paused: false,
    busy: false,
    roles: [role],
    capabilities: ["task.execute", "coding", "reasoning"],
    models: [{ id: `${role}-model`, enabled: true, capabilities: ["task.execute", "coding", "reasoning"], quota: { state: "Healthy" } }],
    executors: [{ health: "Healthy", quota: "Healthy" }],
  };
}
